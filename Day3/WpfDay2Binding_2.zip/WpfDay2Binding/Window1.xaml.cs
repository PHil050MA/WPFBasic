﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfDay2Binding
{
    /// <summary>
    /// Window1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Window1 : Window
    {
        //public List<Person> People { get; set; }
        public ObservableCollection<Person> People { get; set; }
        public Window1()
        {
            InitializeComponent();
            //People = new List<Person>();
            People = new ObservableCollection<Person>();
            DataContext = this; 
        }

        private void AddPersonButton_Click(object sender, RoutedEventArgs e)
        {            
            string name = txtName.Text;
            int age = int.Parse(txtAge.Text);

            Person newPerson = new Person { Name = name, Age = age };
            People.Add(newPerson);


            txtName.Clear();
            txtAge.Clear();
            
        }
    }

    // Person 클래스 정의
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}