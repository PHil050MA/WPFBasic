﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.Design.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfDay2
{
    internal class MemberServiece
    {
        //private static List<Person> member = null;
        public static ObservableCollection<Person> member;

        private MemberServiece()
        {          
            
        }

        public static ObservableCollection<Person> getMember()
        {
            if (member == null)
            {
                member = new ObservableCollection<Person>();
            }
            return member;
        }

        

        public static void addMember(ObservableCollection<Person> p, Person person)
        {
            p.Add(person);
        }



    }
}
