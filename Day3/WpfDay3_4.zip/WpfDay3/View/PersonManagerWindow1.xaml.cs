﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfDay3
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class PersonManagerWindow1 : Window
    {        

        //ObservableCollection<Person> member = null;
        public PersonManagerWindow1()
        {
            InitializeComponent();

            PersonService personService = new PersonService();
            personService.initMember();
            ObservableCollection<Person> member = personService.selectMember();

            memberList.ItemsSource = member;
        }


        private void Add_member(object sender, RoutedEventArgs e)
        {
            Person member = new Person()
            {
                ID = id.Text,
                Password = pw.Text,
                Name = name.Text,
                Phone = phone.Text,
                Gender = "M"
            };

            PersonService personService = new PersonService();
            personService.insertMember(member);
        }

        Person selectedPerson = null;
        private void memberList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedPerson = memberList.SelectedItem as Person;

            if (selectedPerson != null)
            {
                id_up.Text = selectedPerson.ID;
                pw_up.Text = selectedPerson.Password;
                name_up.Text = selectedPerson.Name;
                phone_up.Text = selectedPerson.Phone;
            }
            else
            {
                id_up.Text = "";
                pw_up.Text = "";
                name_up.Text = "";
                phone_up.Text = "";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            selectedPerson.ID = id_up.Text;
            selectedPerson.Password = pw_up.Text;
            selectedPerson.Name = name_up.Text;
            selectedPerson.Phone = phone_up.Text;

            id_up.Text = "";
            pw_up.Text = "";
            name_up.Text = "";
            phone_up.Text = "";

            //MessageBox.Show(selectedPerson.Phone);
        }
    }
}