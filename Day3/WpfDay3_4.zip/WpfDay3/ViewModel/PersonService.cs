﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfDay3
{
    internal class PersonService
    {
        private static ObservableCollection<Person> member = new ObservableCollection<Person>();

        public void initMember()
        {
            member.Add(new Person() { ID = "m100", Password = "1234", Name = "Hong", Phone = "010-0000-1111", Gender = "M" });
            member.Add(new Person() { ID = "m200", Password = "4321", Name = "Kim", Phone = "010-1000-1000", Gender = "M" });
            member.Add(new Person() { ID = "m300", Password = "12341234", Name = "Song", Phone = "010-0100-1010", Gender = "F" });
            member.Add(new Person() { ID = "m400", Password = "12341111", Name = "Gil", Phone = "010-0010-0101", Gender = "M" });
        }


        public void insertMember(Person person) {
          member.Add(person);
        }
        public void updateMember() { }

        public ObservableCollection<Person> selectMember() {
            return member;
        }

        public void deleteMember(Person person)
        {
            member.Remove(person);
        }

        public int getLength() {
          return member.Count;
        }
    }
}
