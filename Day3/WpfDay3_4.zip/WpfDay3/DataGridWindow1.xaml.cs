﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfDay3
{
    /// <summary>
    /// DataGridWindow1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DataGridWindow1 : Window
    {
        ObservableCollection<Member> members = null;
        public DataGridWindow1()
        {
            InitializeComponent();

            members = new ObservableCollection<Member>();
            members.Add(new Member()
            {
                Name = "HongGilDong",
                Age = 20,
                Email = "hong@abc.com"
            });
            members.Add(new Member()
            {
                Name = "KimGilJun",
                Age = 20,
                Email = "kim@gmail.com"
            });
            members.Add(new Member()
            {
                Name = "KangHanNa",
                Age = 20,
                Email = "khn@abc.com"
            });
            members.Add(new Member()
            {
                Name = "SongMinHa",
                Age = 20,
                Email = "smh@abc.com"
            });

            this.member_dg.ItemsSource = members;
            MessageBox.Show(members.Count.ToString());
        }       

        private void member_dg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {            
            var selectedMember = member_dg.SelectedItem as Member;

            if (selectedMember != null)
            {                
                string name = selectedMember.Name;
                int age = selectedMember.Age;
                string email = selectedMember.Email;
               
                MessageBox.Show($"Selected Member: {name}, Age: {age}, Email: {email}");
            }
        }
    }
}
